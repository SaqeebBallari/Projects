<?php
require('config1.php')
?>

<form action="submit.php" method="post">
    <script
        src="https://checkout.stripe.com/checkout.js" class="stripe-button"
        data-key="<?php echo $publishableKey?>"
        data-amount=""
        data-name="GROCO"
        data-description="Payment"
        data-image="https://www.dreamstime.com/lets-shopping-logo-design-template-cart-icon-designs-image134743663"
        data-currency="inr"

    >
    </script>

</form>