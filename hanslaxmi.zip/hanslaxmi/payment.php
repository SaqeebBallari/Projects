<?php
require('config1.php')
?>

<form action="submit.php" method="post">
    <script
        src="https://checkout.stripe.com/checkout.js" class="stripe-button"
        data-key="<?php echo $publishableKey?>"
        data-amount="50000"
        data-name="Hanslaxmi Dryfruits"
        data-description="Payment"
        data-image="https://www.shutterstock.com/image-vector/silhouette-swan-flapping-wings-logo-260nw-1678991446.jpg"
        data-currency="inr"

    >
    </script>

</form>