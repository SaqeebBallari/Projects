<?php
require('config1.php');

\Stripe\Stripe::setVerifySslCerts(false);

$token=$_POST['stripeToken'];

$data=\Stripe\Charge::create(array(
    "amount"=>500,
    "currency"=>"inr",
    "description"=>"Hanslaxmi Dryfruits",
    "source"=>$token,
));

echo "<pre>";
print_r($data);

?>