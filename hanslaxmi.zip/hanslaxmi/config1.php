<?php
require('stripe-php-master/init.php');

$publishableKey="pk_test_51MVpNnSISrlMDAp9RD1Qfrjv2dDwPDfWeNZ7Z1ksaZlm1VS40IllFNl3NIIUNnBGcPy2pEW4Gb91ofnbfKBOoLxc002t43E2qO";

$secretKey="sk_test_51MVpNnSISrlMDAp9HYfSUNexb5E8RzsNqhv9sIRUPIkne5lhZcJSfHBjw3fNMXKxUCiBi3Y0XBozLHeoRmIV1Jbi00fuGFhnQS";

\Stripe\Stripe::setAPIKey($secretKey);
?>